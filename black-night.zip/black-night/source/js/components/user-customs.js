blackNight.userCustoms = (function() {

	function bindEvents(){
		/**
		 *
		 * You can insert customized code right here
		 */

	}

	return {
		init: function(){
			bindEvents();	
		}
	}

})();

blackNight.userCustoms.init();