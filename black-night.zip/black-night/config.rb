require 'compass-normalize'
preferred_syntax = :scss
http_path = '/'
sass_dir = 'source/sass'
css_dir = 'assets/style'
images_dir = 'assets/images'
images_path = 'source/images'
javascripts_dir = 'assets/js'
fonts_dir = 'assets/fonts'
http_images_path = '../images'
http_generated_images_path = '../images'
line_comments = false
# output_style = :compressed
